﻿Imports System.Runtime.CompilerServices

Public Module IsCurrentActionHelper

    <Extension()> _
    Public Function IsCurrentAction(ByVal helper As HtmlHelper, ByVal actionName As String, ByVal controllerName As String) As Boolean

        Dim currentControllerName As String = helper.ViewContext.RouteData.Values("controller")
        Dim currentActionName As String = helper.ViewContext.RouteData.Values("action")

        If currentControllerName.Equals(controllerName, StringComparison.CurrentCultureIgnoreCase) And currentActionName.Equals(actionName, StringComparison.CurrentCultureIgnoreCase) Then
            Return True
        End If

        Return False
    End Function

End Module

