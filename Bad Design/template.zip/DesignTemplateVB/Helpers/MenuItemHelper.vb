﻿Imports System.Runtime.CompilerServices

''' <summary>
''' This helper method renders a link within an HTML LI tag.
''' A class="selected" attribute is added to the tag when
''' the link being rendered corresponds to the current
''' controller and action.
''' 
''' This helper method is used in the Site.Master View 
''' Master Page to display the website menu.
''' </summary>


Public Module MenuItemHelper


    <Extension()> _
    Public Function MenuItem(ByVal helper As HtmlHelper, ByVal linkText As String, ByVal actionName As String, ByVal controllerName As String) As String
        Return MenuItem(helper, linkText, actionName, controllerName, "selected")
    End Function

    <Extension()> _
    Public Function MenuItem(ByVal helper As HtmlHelper, ByVal linkText As String, ByVal actionName As String, ByVal controllerName As String, ByVal className As String) As String

        Dim currentControllerName As String = helper.ViewContext.RouteData.Values("controller")
        Dim currentActionName As String = helper.ViewContext.RouteData.Values("action")

        Dim sb = New StringBuilder()

        If currentControllerName.Equals(controllerName, StringComparison.CurrentCultureIgnoreCase) And currentActionName.Equals(actionName, StringComparison.CurrentCultureIgnoreCase) Then
            sb.AppendFormat("<li class=""{0}"">", className)
        Else
            sb.Append("<li>")
        End If

        sb.Append(helper.ActionLink(linkText, actionName, controllerName))
        sb.Append("</li>")
        Return sb.ToString()
    End Function


End Module
