//////  Blue Blog MVC Template  \\\\\\
______________________________________________________

Designed by Mehmet Duran - mehmetduran.com

______________________________________________________

You can see this template mvc.mehmetduran.com

______________________________________________________


For cantact me you can use mehmetduran@hotmail.com

______________________________________________________