Hi,

I am Janki Mehta. You can view my portfolio at http://www.mywebarts.com
Since you will use this template I think I earned 10 secs of your time
for the following line!

--Marketing Blah-------
Please don't hesitate to contact me for any design works. I work at $15/hour.
--End Marketing Blah-------


I hereby grant Creative Commons Attribution 3.0 license to the user of this template.

The masterPages are included in the template. If you need additional help customizing or PSD for the same
please don't hesitate to contact me at janki@mywebarts.com

Best Regards,
Janki Mehta.