How to use Slave Leia
=====================
Create a new MVC project of your own by using 
'New Project' --> web -> Asp.net MVC Web Application

Replace the "Content" folder you receive with the content folder from this zip file.


How Was This Template Made Possible?
====================================
I would like to take credit for this amazing template -- but the simple truth is that a group of militant html-sculptors from a distant future punched a worm-hole through space and time, to bring us this work of genius.


And another thing
=================

I blogged about the need for an MVC Gallery (and the slave leia concept) long before the actual site was launched. Premonition dude! Check it out here:

http://secretgeek.net/mvc_zen_garden_idea.asp



Contribute Back to the Community!
=================================
Did this ASP.NET MVC Design Template make your life better? Contribute back to the community:

  * Vote for this design at the ASP.NET MVC Design Gallery. Click the thumbs-up button next to the design in the gallery to vote for it.

  * Contribute your own ASP.NET MVC Design. Promote your design skills and submit an original design to the ASP.NET MVC Design Gallery.


Visit the ASP.NET MVC Design Gallery at:

  http://www.ASP.net/mvc/gallery



