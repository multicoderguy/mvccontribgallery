﻿using System;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace BookReviewsWAP
{
    public partial class ShowCoverImage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            // Returns the CoverImage BLOB in the database
            byte[] coverImageBuffer = null;

            using (SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ReviewsConnectionString"].ConnectionString))
            {
                string getImageSql = "SELECT CoverImage FROM Books WHERE BookId = @BookId";
                SqlCommand myCommand = new SqlCommand(getImageSql, myConnection);
                myCommand.Parameters.AddWithValue("@BookId", Request.QueryString["ID"]);

                myConnection.Open();
                coverImageBuffer = myCommand.ExecuteScalar() as byte[];
                myConnection.Close();
            }

            // Return the binary image contents
            Response.ContentType = "image/jpeg";
            Response.BinaryWrite(coverImageBuffer);
        }
    }
}
