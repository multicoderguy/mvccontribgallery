﻿using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Admin_CreateEditReview : BasePage
{
    protected void Page_Load(object sender, EventArgs e)
    {
        if (!Page.IsPostBack)
        {
            // Are we editing a review or creating a new one?
            if (this.EditingBookId != Guid.Empty)
            {
                // Yes, we are editing a review
                PageMessage.Text = "Edit a Book Review";
                btnSaveUpdate.Text = "Update";

                // Load the book's values into the UI
                LoadReview();
            }
            else
            {
                // We are creating a new review
                PageMessage.Text = "Create a New Book Review";
                btnSaveUpdate.Text = "Create";
                CurrentImagePanel.Visible = false;
            }
        }
    }

    private void LoadReview()
    {
        using (SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ReviewsConnectionString"].ConnectionString))
        {
            string getReviewSql = "SELECT * FROM Books WHERE BookID = @BookID";

            SqlCommand myCommand = new SqlCommand(getReviewSql, myConnection);
            myCommand.Parameters.AddWithValue("@BookID", this.EditingBookId);

            myConnection.Open();
            SqlDataReader myReader = myCommand.ExecuteReader();

            if (myReader.Read())
            {
                BookTitle.Text = myReader["Title"].ToString();
                ISBN.Text = myReader["ISBN"].ToString();
                Genre.SelectedValue = myReader["GenreId"].ToString();
                PublishDate.Text = Convert.ToDateTime(myReader["PublishDate"]).ToShortDateString();
                ReviewDate.Text = Convert.ToDateTime(myReader["ReviewDate"]).ToShortDateString();
                Review.Text = myReader["Review"].ToString();

                if (Convert.IsDBNull(myReader["CoverImage"]))
                {
                    CurrentImagePanel.Visible = false;
                }
                else
                {
                    CurrentImagePanel.Visible = true;
                    CurrentImage.ImageUrl = "~/ShowCoverImage.aspx?ID=" + myReader["BookId"].ToString();
                }
            }
            else
            {
                // No book was found!
                throw new ArgumentException(string.Format("Could not find book with ID '{0}'", this.EditingBookId));
            }

            myReader.Close();


            // Now get the list of authors who contributed to this book and check the CheckBoxes as needed
            Authors.DataBind();

            string getAuthorsSql = "SELECT AuthorId FROM BooksAuthors WHERE BookID = @BookID";
            myCommand.CommandText = getAuthorsSql;

            myReader = myCommand.ExecuteReader();
            while (myReader.Read())
            {
                ListItem li = Authors.Items.FindByValue(myReader["AuthorId"].ToString());
                if (li != null)
                    li.Selected = true;
            }

            myReader.Close();
            myConnection.Close();
        }
    }

    private Guid EditingBookId
    {
        get
        {
            if (string.IsNullOrEmpty(Request.QueryString["ID"]))
                return Guid.Empty;
            else
                return new Guid(Request.QueryString["ID"]);
        }
    }

    protected void btnSaveUpdate_Click(object sender, EventArgs e)
    {
        // Ensure the user input is valid
        if (!Page.IsValid)
            return;

        // Load up the list of selected authors
        List<Guid> AuthorIds = new List<Guid>();
        foreach (ListItem li in Authors.Items)
            if (li.Selected)
                AuthorIds.Add(new Guid(li.Value));

        // Make sure at least one author has been selected
        if (AuthorIds.Count == 0)
        {
            base.DisplayAlert("You must select at least one author.");
            return;
        }

        // Save the results using a transaction (see http://aspnet.4guysfromrolla.com/articles/072705-1.aspx)
        string sql = string.Empty;
        Guid BookId = Guid.Empty;

        if (this.EditingBookId == Guid.Empty)
        {
            // Need to insert the data
            sql = "INSERT INTO Books(BookId, Title, GenreId, ISBN, PublishDate, ReviewDate, Review) VALUES(@BookId, @Title, @GenreId, @ISBN, @PublishDate, @ReviewDate, @Review)";
            BookId = Guid.NewGuid();
        }
        else
        {
            // Need to update the data
            sql = "UPDATE Books SET Title = @Title, GenreId = @GenreId, ISBN = @ISBN, PublishDate = @PublishDate, ReviewDate = @ReviewDate, Review = @Review WHERE BookId = @BookId";
            BookId = this.EditingBookId;
        }

        using (SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ReviewsConnectionString"].ConnectionString))
        {
            SqlTransaction myTrans = null;

            try
            {
                myConnection.Open();
                myTrans = myConnection.BeginTransaction();

                // *** Step 1: Add/Update the core Books fields ***
                SqlCommand myCommand = new SqlCommand(sql, myConnection, myTrans);
                myCommand.Parameters.AddWithValue("@BookId", BookId);
                myCommand.Parameters.AddWithValue("@Title", BookTitle.Text.Trim());
                myCommand.Parameters.AddWithValue("@GenreId", Genre.SelectedValue);
                myCommand.Parameters.AddWithValue("@ISBN", ISBN.Text.Trim());
                myCommand.Parameters.AddWithValue("@ReviewDate", ReviewDate.Text.Trim());
                myCommand.Parameters.AddWithValue("@PublishDate", PublishDate.Text.Trim());
                myCommand.Parameters.AddWithValue("@Review", Review.Text.Trim());

                myCommand.ExecuteNonQuery();
                // *************************************************


                // *** Step 2: Update the cover image, if needed ***
                if (CoverImageUpload.HasFile)
                {
                    string imageSql = "UPDATE Books SET CoverImage = @CoverImage WHERE BookId = @BookId";
                    myCommand.CommandText = imageSql;
                    myCommand.Parameters.Clear();

                    myCommand.Parameters.AddWithValue("@BookId", BookId);
                    myCommand.Parameters.AddWithValue("@CoverImage", CoverImageUpload.FileBytes);

                    myCommand.ExecuteNonQuery();
                }
                // *************************************************


                // *** Step 3: Set the Authors ***
                string obliterateAuthorsSql = "DELETE FROM BooksAuthors WHERE BookId = @BookId";
                string addAuthorSql = "INSERT INTO BooksAuthors(AuthorId, BookId) VALUES(@AuthorId, @BookId)";

                // First clear out all authors for this book
                myCommand.CommandText = obliterateAuthorsSql;
                myCommand.Parameters.Clear();
                myCommand.Parameters.AddWithValue("@BookId", BookId);
                myCommand.ExecuteNonQuery();

                // Next, add in a record for each selected author
                myCommand.CommandText = addAuthorSql;

                foreach (Guid authId in AuthorIds)
                {
                    myCommand.Parameters.Clear();
                    myCommand.Parameters.AddWithValue("@BookId", BookId);
                    myCommand.Parameters.AddWithValue("@AuthorId", authId);
                    myCommand.ExecuteNonQuery();
                }
                // *************************************************


                // If we reach here, commit the transaction
                myTrans.Commit();
            }
            catch
            {
                // Rollback the transaction
                myTrans.Rollback();

                throw;
            }
        }

        // Refresh the site map so that any changes/additions are reflected in the site map
        ReviewSiteMapProvider mySiteMapProvider = SiteMap.Provider as ReviewSiteMapProvider;
        if (mySiteMapProvider != null)
            mySiteMapProvider.RefreshSiteMap();

        // Return the user to ManageReviews
        Response.Redirect("~/Admin/ManageReviews.aspx");
    }

    protected void btnCancel_Click(object sender, EventArgs e)
    {
        // Return the user to ManageReviews
        Response.Redirect("~/Admin/ManageReviews.aspx");
    }

    protected void lnkDeleteCoverImage_Click(object sender, EventArgs e)
    {
        // Set the CoverImage field to NULL
        using (SqlConnection myConnection = new SqlConnection(ConfigurationManager.ConnectionStrings["ReviewsConnectionString"].ConnectionString))
        {
            string clearImageSql = "UPDATE Books SET CoverImage = NULL WHERE BookId = @BookId";
            SqlCommand myCommand = new SqlCommand(clearImageSql, myConnection);
            myCommand.Parameters.AddWithValue("@BookId", this.EditingBookId);

            myConnection.Open();
            myCommand.ExecuteNonQuery();
            myConnection.Close();
        }

        CurrentImagePanel.Visible = false;
    }
}
