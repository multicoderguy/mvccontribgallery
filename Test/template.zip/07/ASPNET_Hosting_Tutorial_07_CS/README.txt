This download provides an ASP.NET application called BookReviews, which is (at this point) a simple hobby website where the site owner can share his book reviews online.

There are two copies of the site, one copy is implemented as a Web Site Project (BookReviewsWSP) and one is implemented as a Web Application Project (BookReviewsWAP). Both projects were created using Visual Web Developer 2008 SP1 and use ASP.NET 3.5 SP1.

To open the Web Site Project, fire up Visual Studio 2008 (or Visual Web Developer 2008), go to File --> Open Web Site and point to the project folder, BookReviewsWSP.

To open the Web Application project, double-click the Solution file, BookReviewsWAP.sln, which is located in the BookReviewsWAP folder.

If you do not have Visual Studio 2008 you can download Visual Web Developer at:
http://www.microsoft.com/express/vwd/

Additionally, these projects include a database file in the App_Data folder named Reviews.mdf. This database is a SQL Server 2008 Express Edition database. If you do not have SQL Server 2008 installed on your computer you can download the free Express Edition at:
http://www.microsoft.com/express/sql


-- Scott Mitchell
-- mitchell@4guysfromrolla.com
-- http://www.ScottOnWriting.NET